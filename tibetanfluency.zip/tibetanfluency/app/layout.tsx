import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Tibetan Language Course - Learn Clearly, Confidently, and Step-by-Step',
  description: 'A modern, structured Tibetan language program designed to help beginners and dedicated learners finally understand Tibetan with clarity and ease.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  );
}
